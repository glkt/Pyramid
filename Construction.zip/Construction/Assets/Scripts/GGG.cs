﻿using UnityEngine;
using System.Collections;

static class GGG {

	public static int peeps = 4;

	public static int gridMaxUnits = 9;
	public static int gridSize = 1;
}
